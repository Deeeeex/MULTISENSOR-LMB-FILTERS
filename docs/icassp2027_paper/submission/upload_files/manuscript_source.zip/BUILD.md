# ICASSP 2027 manuscript source

Compile from this directory with:

    tectonic --keep-logs --keep-intermediates main.tex

The archive intentionally contains only the manuscript source, bibliography,
conference style, and the two PDF figures used by `main.tex`. Generated TeX
intermediates, PNG previews, experiment artifacts, and internal review notes
are excluded.
