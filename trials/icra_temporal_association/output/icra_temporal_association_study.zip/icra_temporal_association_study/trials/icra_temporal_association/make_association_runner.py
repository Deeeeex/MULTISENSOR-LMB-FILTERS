"""Generate the new matcher replay with a bounded diff from verified instrumentation."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
source = OUT / 'recordAssociationReplay.m'
text = source.read_text()
changes = [
    ('function recordAssociationReplay(configPath,unitIndex)',
     'function runAssociationReplay(configPath,unitIndex)'),
    ("assert(strcmp(which('Hungarian'),fullfile(runtimePath,'Hungarian.m')));",
     "assert(strcmp(which('Hungarian'),fullfile(runtimePath,'Hungarian.m')));\ncheckObservationAssociation();"),
    ('template.localSpatialLogRatio=zeros(1,15);',
     'template.localSpatialLogRatio=zeros(1,15);template.localDirectObservation=zeros(1,8);'),
    ("'localDirectRecords',zeros(0,12),'iterationRecords'",
     "'localDirectRecords',zeros(0,12),'packetDirectRecords',zeros(0,12),'associationRecords',zeros(0,10),'associationStats',zeros(0,11),'associationAbstentions',zeros(0,4),'associationReopenings',zeros(0,8),'iterationRecords'"),
    ("marked=startsWith(arm,'marked_');rule=erase(arm,'marked_');",
     "marked=startsWith(arm,'marked_');rule=erase(arm,'marked_');\nassociationMode='';\nif endsWith(rule,'_assoc_direct'),associationMode='direct';rule=erase(rule,'_assoc_direct');\nelseif endsWith(rule,'_assoc_temporal'),associationMode='temporal';rule=erase(rule,'_assoc_temporal');end"),
    ('cfg.captureIterationRecords=true;',
     "cfg.captureIterationRecords=true;\nemptyHistory=struct('frame',{},'left',{},'right',{},'qualified',{},'distance',{});\nassociationMemory={emptyHistory,emptyHistory};"),
    ('                before=predicted(indices(j));after=local{n}(j);',
     '                local{n}(j).localDirectObservation=directValues(indices(j),:);\n                before=predicted(indices(j));after=local{n}(j);'),
    ("            if startsWith(rule,'gaussian_evidence')\n                [decoded{n},packet]=gaussianEvidencePacket(local{n},model,n,t);",
     "            if startsWith(rule,'gaussian_evidence') || ~isempty(associationMode)\n                if isempty(associationMode),[decoded{n},packet]=gaussianEvidencePacket(local{n},model,n,t);\n                else,[decoded{n},packet]=observationEvidencePacket(local{n},model,n,t);end"),
    ('                    o=decoded{n}(j);\n                    run.packetGaussianRecords',
     "                    o=decoded{n}(j);\n                    if ~isempty(associationMode),run.packetDirectRecords(end+1,:)=[t,n,o.birthTime,o.birthLocation,o.localDirectObservation];end %#ok<AGROW>\n                    run.packetGaussianRecords"),
    ('            [remote,matching]=alignGaussianLmbPair(local{n},decoded{other},50);',
     "            if isempty(associationMode)\n                [remote,matching]=alignGaussianLmbPair(local{n},decoded{other},50);\n            else\n                [remote,matching,associationMemory{n}]=alignObservationLmbPair(local{n},decoded{other},50,associationMemory{n},associationMode,t);\n            end"),
    ("            details.originalLabels={[[local{n}.birthTime];[local{n}.birthLocation]], ...\n                [[decoded{other}.birthTime];[decoded{other}.birthLocation]]};",
     """            originalRemote=decoded{other};
            if ~isempty(associationMode)
                originalRemote=originalRemote(matching.keptRemoteIndices);
                run.associationStats(end+1,:)=[t,n,numel(local{n}),numel(decoded{other}),matching.knownPairs,matching.assignedPairs, ...
                    matching.reopenedKnown,matching.droppedRemote,size(matching.abstainLabels,2),matching.qualifiedPairs,matching.historyPairs]; %#ok<AGROW>
                for k=1:size(matching.pairs,1)
                    pair=matching.pairs(k,:);a=local{n}(pair(1));b=decoded{other}(pair(2));
                    run.associationRecords(end+1,:)=[t,n,a.birthTime,a.birthLocation,b.birthTime,b.birthLocation,pair(3:6)]; %#ok<AGROW>
                end
                if ~isempty(matching.reopenedRecords)
                    run.associationReopenings=[run.associationReopenings;repmat([t,n],size(matching.reopenedRecords,1),1),matching.reopenedRecords]; %#ok<AGROW>
                end
                for k=1:size(matching.abstainLabels,2)
                    label=matching.abstainLabels(:,k);
                    details.labelSpecificWeightOverrides(k)=struct('label',label,'sourceInputIndex',1, ...
                        'replacedInputIndex',2,'mode','dominant-nonself-transfer');
                    run.associationAbstentions(end+1,:)=[t,n,label']; %#ok<AGROW>
                end
            end
            details.originalLabels={[[local{n}.birthTime];[local{n}.birthLocation]], ...
                [[originalRemote.birthTime];[originalRemote.birthLocation]]};""")]
for old, new in changes:
    assert text.count(old) == 1, old
    text = text.replace(old, new)
destination = OUT / 'runAssociationReplay.m'
assert not destination.exists()
destination.write_text(text)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
(OUT / 'ASSOCIATION_RUNNER_PATCH.json').write_text(json.dumps(dict(
    source=str(source.relative_to(ROOT)), source_sha256=sha(source),
    destination=str(destination.relative_to(ROOT)), destination_sha256=sha(destination),
    bounded_replacements=changes), indent=2) + '\n')
